import{j as t}from"./index-BzwXDzQw.js";import{a as d}from"./router-YxmvAxAM.js";const l=d.forwardRef(({glass:a,className:r="",children:e,...s},o)=>t.jsx("div",{ref:o,className:`
        rounded-xl border border-neutral-200 bg-white p-5 shadow-sm
        dark:border-neutral-700 dark:bg-neutral-800
        ${a?"backdrop-blur-md bg-white/70 dark:bg-neutral-800/70":""}
        ${r}
      `.trim(),...s,children:e}));l.displayName="Card";const n=d.forwardRef(({className:a="",...r},e)=>t.jsx("div",{ref:e,className:`mb-3 flex items-center justify-between ${a}`,...r}));n.displayName="CardHeader";const i=d.forwardRef(({className:a="",children:r,...e},s)=>t.jsx("h3",{ref:s,className:`text-lg font-semibold text-neutral-900 dark:text-neutral-50 ${a}`,...e,children:r}));i.displayName="CardTitle";const m=d.forwardRef(({className:a="",...r},e)=>t.jsx("div",{ref:e,className:a,...r}));m.displayName="CardContent";export{l as C,m as a,n as b,i as c};
